globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/b512828fa85e3f74.js",
    "static/chunks/38cb1589c99e9c99.js",
    "static/chunks/87037a5848f6727d.js",
    "static/chunks/5cd2b83c942a8e0a.js",
    "static/chunks/turbopack-47a908ccafac1381.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];