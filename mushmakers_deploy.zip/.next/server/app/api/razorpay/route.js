var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/razorpay/route.js")
R.c("server/chunks/[externals]__1b8b210d._.js")
R.c("server/chunks/[root-of-the-server]__3cfc987d._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_razorpay_route_actions_1dabcd13.js")
R.m(35217)
module.exports=R.m(35217).exports
