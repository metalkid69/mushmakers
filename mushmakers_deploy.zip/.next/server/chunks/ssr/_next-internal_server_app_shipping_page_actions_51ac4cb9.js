module.exports=[70222,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_shipping_page_actions_51ac4cb9.js.map